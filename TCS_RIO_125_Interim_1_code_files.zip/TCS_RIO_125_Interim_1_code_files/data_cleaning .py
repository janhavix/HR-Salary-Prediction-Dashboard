#!/usr/bin/env python
# coding: utf-8

# In[1]:


#TCS iON RIO-125: HR Salary Dashboard - Train the Dataset and Predict Salary (2023)
#Janhavi Shelke (Vishwakarma University, Pune)
#Data cleaning


# In[ ]:


import pandas as pd


# In[13]:


df=pd.read_csv("D:/TCS/HRDataset_v14.csv")


# In[ ]:


df.shape


# In[24]:


df.columns


# In[14]:


df=df.filter(['Employee_Name','State','GenderID','Sex','DeptID','Department','PositionID','Position','DOB','DateofHire', 'DateofTermination','LastPerformanceReview_Date','Salary'],axis=1)


# In[8]:


import datetime as dt
from datetime import datetime
today = datetime.today()


# In[15]:


df['DOB'] = pd.to_datetime(df.DOB)
df['LastPerformanceReview_Date'] = pd.to_datetime(df.LastPerformanceReview_Date)
df['DateofHire'] = pd.to_datetime(df.DateofHire)


# In[16]:


df['Age']=(today.year - df['DOB'].dt.year)


# In[17]:


df['yrs_of_exp']=(df['LastPerformanceReview_Date'].dt.year-df['DateofHire'].dt.year)


# In[ ]:


df.State = pd.Categorical(df.State)


# In[ ]:


df['StateID'] = df.State.cat.codes


# In[28]:


df=df.drop(['Employee_Name','DOB', 'DateofHire', 'DateofTermination','LastPerformanceReview_Date'], axis=1)


# In[ ]:


df.head()


# In[36]:


df.isnull().any()


# In[30]:


df.to_csv('newData')

