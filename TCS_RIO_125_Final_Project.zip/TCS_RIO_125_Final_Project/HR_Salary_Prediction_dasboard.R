

df<-read.csv("D:/TCS/newdf.csv", strip.white = TRUE)
#head(df)
#sapply(df,class)


#install.packages('shiny')
#install.packages('dplyr')
#install.packages("leaflet")
#install.packages("tidyverse")
#install.packages("maps")


library(shiny)
library(dplyr)
library(tidyverse)
library(leaflet)
library(maps)


ui <- fluidPage(
  titlePanel(h2("HR Salary Prediction Dashboard")),
  sidebarLayout(
    sidebarPanel(
      
    uiOutput("Department"),
    uiOutput("Position"),
    uiOutput("State"),
    uiOutput("Age"),
    uiOutput("Exp"),
    div(strong("Salary")),
    br(),
    uiOutput("Salary")
    ),
    
    mainPanel(
      leafletOutput("Map", height= 500)
    )
  )
)

server <- function(input, output, session) {
  
  
  output$Department<-renderUI({
    
    selectizeInput("Dept", "Department",
                   choices = c(sort(unique(df$Department))),
                   multiple = FALSE,
                   
    )
  })
  
  output$Position <- renderUI({
    
    Position <- sort(unique((df %>%filter(Department%in% input$Dept))$Position))
    
    selectizeInput("Position", "Position",
                   choices = c(Position),
                   multiple = FALSE)
                  
  })
  
  output$State<-renderUI({
    
    State<-sort(unique((df %>%filter(Department%in% input$Dept,Position%in% input$Position))$State_full))
    
    selectInput("State", "State",
                choices = c(State),
                multiple = FALSE)
  })
  
  output$Age<-renderUI({
    numericInput('Age','Age', value = 0)
  })
  
  output$Exp<-renderUI({
    numericInput('Exp','Exp',value=0)
  })
  
  subData<-reactive({
    req(input$Dept, input$Position, input$Age)
    subdf<-df %>% mutate_if(is.factor, as.numeric)%>%filter(Position%in% input$Position)
  })
  
  model<-reactive({
    fit<-lm(data=subData(),Salary~DeptID+PositionID+StateID+Age+yrs_of_exp)
    
  })
  
  
  
  modData<-reactive({
    subdf<-subData()
    data.frame(DeptID=as.numeric(unique(subdf$DeptID[subdf$Department==input$Dept])),
               PositionID=as.numeric(unique(subdf$PositionID[subdf$Position==input$Position])),
               StateID=as.numeric(unique(subdf$StateID[subdf$State_full==input$State])),
               yrs_of_exp=as.numeric(input$Exp),
               Age=as.numeric(input$Age))
  })
  

  
  reslt<-reactive({
    predict(model(), newdata=modData())
  })
  
  output$Salary<- renderText({
    print(reslt())
  })
   
  
  
  
  output$Map<-renderLeaflet({
    leaflet(df)%>%
      addProviderTiles(providers$Stamen.TonerLite)%>%
      setView(lng = -98.583, lat = 39.833, zoom = 4)# %>%
     
  })
  
  sel<-reactive({
    isolate(unique(subData()[["State"]]))
    
  })
    
  
  selMp<-map("state",fill = TRUE)
  
  observe({
   
    
    leafletProxy("Map")%>%
      clearShapes() %>%
      addPolygons(data=selMp,
                  fillColor = "lightblue",
                  color = "#BDBDC3",
                  stroke = FALSE, 
                  smoothFactor = 0.2,
                  #group= sel()
                
      )
  })
 
 
    
 
  
  #m<-leafletProxy("Map",session )
  
 
     
 
  
    
  
}

shinyApp(ui,server)


head(df1)
selCntry<-reactive({
  cntry<-df[(df%>%filter(Position%in% input$Position))$State_full,]
})


})

observeEvent(input$Dept, input$Position{
  #req(subData())
  subdf<-subData()
  leafletProxy("Map", data=subData())%>%
    addPolygons(data=data.frame(unique(subdf$State_full[subdf$State==input$State])),
                fillColor = "lightblue",
                stroke = FALSE, 
                smoothFactor = 0.2, 
                fillOpacity = 1,
    )
  
})

observe({
  #req(subData())
  

